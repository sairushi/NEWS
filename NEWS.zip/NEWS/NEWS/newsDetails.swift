//
//  newsDetails.swift
//  NEWS
//
//  Created by mymac on 31/07/19.
//  Copyright © 2019 mymac. All rights reserved.
//

import Foundation

struct articleList:Decodable {
    let articles: [News]
}

struct News:Decodable {
    let author:String?
    let title:String
    let description:String
    let url:String
    let urlToImage:String?
    let publishedAt:String
    
    init(author:String,title:String,description:String,url:String,urlToImage:String,publishedAt:String) {
        self.author = author
        self.title = title
        self.description = description
        self.url = url
        self.urlToImage = urlToImage
        self.publishedAt = publishedAt
        
    }
}
